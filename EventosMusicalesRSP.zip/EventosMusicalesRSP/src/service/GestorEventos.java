
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T>{
    private List<T> eventos = new LinkedList<>();
    Iterator<T> it = eventos.iterator();

    @Override
    public void agregar(T evento) {
        if (evento == null){
            throw new IllegalArgumentException("No puedo almacenar");
        }
        eventos.add(evento);
    }

    @Override
    public void eliminar(int indice) { //rev
        validarIndice(indice);
        eventos.remove(indice);
        
        for (T evento: eventos){
            System.out.println(evento);
        }
    }

    private void validarIndice(int indice){
        if(!(indice > 0 && indice < eventos.size())){ //(indice < 0 || indice >= tamanio());
            throw new IndexOutOfBoundsException("No es valido el indice");
        }    
    }

    @Override
    public void ordenar() {
        if (!eventos.isEmpty() && eventos.get(0) instanceof Comparable){ 
            ordenar((Comparator<T>) Comparator.naturalOrder());
        }
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        eventos.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        for (T evento : eventos){
            if (predicate.test(evento)){
                toReturn.add(evento);
            }
        }
        return toReturn; 
    }
        

    @Override
    public void guardarEnCSV(String path) throws IOException { ///////////////////////////
        BufferedWriter bw = new BufferedWriter(new FileWriter(path));
        bw.write(eventos.get(0).toHeaderCSV() + "\n");
        for (T evento : eventos){
            bw.write(evento.toCSV() + "\n") ;
        }
        bw.close();
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException {
        eventos.clear();
        BufferedReader br = new BufferedReader(new FileReader(path));
        String linea = "";
        br.readLine();
        while((linea = br.readLine()) != null){
            if(linea.endsWith("\n")){
                linea = linea.substring(linea.length() -1);
            }
            eventos.add(transformadora.apply(linea));
        }
        br.close();
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException { //////////////////////////////////////
        eventos.clear();
        
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path));
        eventos.addAll((List<T>) entrada.readObject());
        entrada.close(); 
    }

    @Override
    public void guardarEnBinario(String path) throws IOException {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path));
        
        salida.writeObject(eventos);
        salida.close(); 
    }


    @Override
    public void mostrarTodos() {
        System.out.println("Lista eventos: ");
        for(T evento : eventos){
            System.out.println(evento);
        }
    }
    
    
}
