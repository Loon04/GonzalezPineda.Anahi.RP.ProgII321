
package model;

import java.time.LocalDate;

public abstract class Evento {
    private int id;
    private String nombre;
    private LocalDate fechaEvento;

    public Evento(int id, String nombre, LocalDate fechaEvento) {
        this.id = id;
        this.nombre = nombre;
        this.fechaEvento = fechaEvento;
    }

    public LocalDate getFechaEvento() {
        return fechaEvento;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }
    
    
    @Override
    public String toString() {
        return "id=" + id + ", nombre=" + nombre + ", fechaEvento=" + fechaEvento;
    }
    
    
}
