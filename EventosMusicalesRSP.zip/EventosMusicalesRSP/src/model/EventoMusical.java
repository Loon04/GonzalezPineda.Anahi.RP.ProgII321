
package model;

import java.time.LocalDate;
import service.CSVSerializable;


public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable{
    private String artista;
    private GeneroMusical generoMusical;

    public EventoMusical(int id, String nombre, LocalDate fechaEvento, String artista, GeneroMusical generoMusical) {
        super(id, nombre, fechaEvento);
        this.artista = artista;
        this.generoMusical = generoMusical;
    }

    @Override
    public int compareTo(EventoMusical e) { 
        return this.getFechaEvento().compareTo(e.getFechaEvento());

    }

    @Override
    public String toString() {
        return super.toString() + ", artista=" + artista + ", generoMusical=" + generoMusical;
    }

    public GeneroMusical getGeneroMusical() {
        return generoMusical;
    }

    
    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFechaEvento() + "," + artista + "," + generoMusical;
    }

    @Override
    public String toHeaderCSV() {
        return "id,nombre,fechaEvento,artista,generoMusical";
    }
    
    public static EventoMusical fromCSV(String eventoCSV){
        String[] values = eventoCSV.split(",");
        return new EventoMusical(Integer.parseInt(values[0]),
                values[1],
                LocalDate.parse(values[2]),
                values[3],
                GeneroMusical.valueOf(values[4]));
    } 
}
